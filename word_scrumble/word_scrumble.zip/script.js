// List of words
const words = [
	"Ironman", "Thanos", "Spiderman", "Loki", "Hulk", "Thor", "CaptainAmerica", "BlackWidow",
	"DoctorStrange", "BlackPanther", "Vision", "Wanda", "Falcon", "WinterSoldier", "Antman", "Wasp",
	"ShangChi", "MsMarvel", "CaptainMarvel", "StarLord", "Gamora", "Drax", "Groot", "Rocket", "Nebula",
	"Hawkeye", "SheHulk", "MoonKnight", "Deadpool", "Eternals",

	"Batman",
	"Superman",
	"WonderWoman",
	"Flash",
	"Aquaman",
	"GreenLantern",
	"Cyborg",
	"Joker",
	"HarleyQuinn",
	"Shazam"
];

// Respective list of hints 
const hints = [
	"Genius billionaire in a suit",
	"Infinity Gauntlet wearer",
	"Friendly neighborhood hero",
	"God of Mischief",
	"Green smashing machine",
	"God of Thunder",
	"Super soldier with a shield",
	"Master spy and martial artist",
	"Master of the Mystic Arts",
	"Wakandan king and warrior",
	"Synthozoid powered by the Mind Stone",
	"Scarlet witch with reality-bending powers",
	"Wingsuit Avenger with red goggles",
	"Bucky Barnes with a metal arm",
	"Shrinks and talks to ants",
	"Flying partner of Ant-Man",
	"Martial arts master with ten rings",
	"Teen with stretchy powers and cosmic energy",
	"One of the strongest Avengers with cosmic blasts",
	"Leader of the Guardians, loves '80s music",
	"Green assassin and Thanos's daughter",
	"Muscular warrior with no filter",
	"Tree-like hero who says one thing",
	"Talking raccoon with a love for big guns",
	"Cybernetic warrior and Gamora's sister",
	"Bow and arrow marksman",
	"Green lawyer with strength and sass",
	"Vigilante with multiple identities",
	"Merc with a mouth and healing powers",
	"Ancient immortal beings protecting Earth",

	"Dark Knight of Gotham",
	"Man of Steel",
	"Amazonian warrior princess",
	"Fastest man alive",
	"King of Atlantis",
	"Wielder of a power ring",
	"Half man, half machine",
	"Clown Prince of Crime",
	"Psychiatrist turned chaotic villain",
	"Boy who becomes a superhero by saying a word"
];

// Initialize display word 
let displayWord = "";

// Function to shuffle letters 
function shuffle(str) {
	strArray = Array.from(str);
	for (let i = 0; i < strArray.length - 1; ++i) {
		let j = Math.floor(Math.random() * strArray.length);
		// Swap letters 
		let temp = strArray[i];
		strArray[i] = strArray[j];
		strArray[j] = temp;
	}
	return strArray.join(" ");
}

// Function to check input and display result 
function check() {
	let input = document.getElementById("input");
	let output = document.getElementById("output");
	if (
		input.value.toLocaleLowerCase() ===
		displayWord.toLocaleLowerCase()
	) {
		output.innerHTML = "Result: Correct";
		fadeOutAndRefresh();
	} else {
		input.style.animation = "shakeAnimation 0.5s ease-in-out";
		setTimeout(() => {
			input.style.animation = "";
		}, 500);
		output.innerHTML = "Result: Incorrect";
	}
}

// To fade out the current word and hint, then show new word and hint
function fadeOutAndRefresh() {
	const scrambleWord = document.getElementById("scrambleWord");
	const hint = document.getElementById("hint");

	scrambleWord.style.transition = "opacity 0.5s";
	hint.style.transition = "opacity 0.5s";
	scrambleWord.style.opacity = "0";
	hint.style.opacity = "0";

	setTimeout(() => {
		refresh();
		scrambleWord.style.opacity = "1";
		hint.style.opacity = "1";
	}, 500);
}

// To refresh and show new word 
function refresh() {
	document.getElementById("input").value = "";
	index = Math.floor(Math.random() * 40);
	displayWord = words[index];
	displayHint = hints[index];
	const scrambleWord = document.getElementById("scrambleWord");
	scrambleWord.innerText = shuffle(displayWord).toUpperCase();
	const hint = document.getElementById("hint");
	hint.innerHTML = "<b>Hint:</b> " + displayHint;
	// document.getElementById("output").innerText = "Result:";
}

// Function call when page load for first time 
refresh();
